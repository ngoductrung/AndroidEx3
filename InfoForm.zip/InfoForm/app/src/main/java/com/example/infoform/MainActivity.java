package com.example.infoform;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.service.autofill.OnClickAction;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText phonetext, SID, email, name, Bd;
    Button Submit;
    CheckBox Term;
    TextView shownoti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phonetext = findViewById(R.id.TextPhone);
        SID = findViewById(R.id.edit_id);
        email = findViewById(R.id.edit_email);
        name = findViewById(R.id.edit_name);
        Bd = findViewById(R.id.editTextDate);
        Term = findViewById(R.id.checkTerm);
        shownoti = findViewById(R.id.noti);

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if((phonetext.getText()!= null) && (SID.getText()!=null) && (email.getText()!=null) && (name.getText()!=null)
                        && (Bd.getText()!=null) && (Term.isChecked())){
                    shownoti.setText("Success");
                }else
                    shownoti.setText("Check again!!");
            }
        });
    }


}